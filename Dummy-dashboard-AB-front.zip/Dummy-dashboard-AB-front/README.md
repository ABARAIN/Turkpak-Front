check directory (using ls)
enter in dummy-dashboard directory
run npm install (make sure npm is installed on your system and path specified in env variables)
once all dependencies installed, npm run dev
